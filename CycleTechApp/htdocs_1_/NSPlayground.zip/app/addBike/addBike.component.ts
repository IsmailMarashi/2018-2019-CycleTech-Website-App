import { SegmentedBar, SegmentedBarItem } from "tns-core-modules/ui/segmented-bar";
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { CartComponent } from "../shared/cartfunctions";




@Component({
    selector: "gr-addBike",
    providers: [UserService, CartComponent],
    templateUrl: "addBike/addBike.component.html",
    styleUrls: ["app.css"],
})
export class AddBikeComponent implements OnInit {
    s: Array<String> = ["Servicing", "Available", "Broken", "Pending", "In-use"];
    s1: Array<String> = ["Alexei", "Kata", "Toinette", "Sheridan", "Osborn-use"];
    make: String = new String();
    model: String = new String();
    color: String = new String();
    terminal: String = new String();
    terminalID: Number = new Number();
    status: String = new String();
    price: Number = 0.10;
    amount: Number = 1;
    private getSegmentedBarItems = () => {
        let sb1 = new SegmentedBarItem();
        sb1.title = <string>this.s[0];
        let sb2 = new SegmentedBarItem();
        sb2.title = <string>this.s[1];
        let sb3 = new SegmentedBarItem();
        sb3.title = <string>this.s[2];
        let sb4 = new SegmentedBarItem();
        sb4.title = <string>this.s[3];
        let sb5 = new SegmentedBarItem();
        sb5.title = <string>this.s[4];
        return [sb1, sb2, sb3, sb4, sb5];
    }
    private gettb = () => {
        let sb1 = new SegmentedBarItem();
        sb1.title = <string>this.s1[0];
        let sb2 = new SegmentedBarItem();
        sb2.title = <string>this.s1[1];
        let sb3 = new SegmentedBarItem();
        sb3.title = <string>this.s1[2];
        let sb4 = new SegmentedBarItem();
        sb4.title = <string>this.s1[3];
        let sb5 = new SegmentedBarItem();
        sb5.title = <string>this.s1[4];
        return [sb1, sb2, sb3, sb4, sb5];
    }
    segmentedBarItems: Array<SegmentedBarItem> = this.getSegmentedBarItems();
    selectedBarIndex: number = 0;
    tb: Array<SegmentedBarItem> = this.gettb();

    selectedBarIndex1: number = 0;
    user: User;
    //  Make | Model | Color | Terminalnum | Status | Lat | Lng | Price | terminalID

    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
    }
    addbike() {
        if (this.make != '' && this.model != '' && this.color != '') {
            this.cart.addbike(this.make, this.model, this.color, this.terminal, this.terminalID, this.status, this.price, this.amount).subscribe();
        }
        else {
            alert("make sure make, model, or color are not null before submitting");
        }
    }
    public tIndexChange(args) {
        let segmentedBar = <SegmentedBar>args.object;
        this.terminal = this.s1[segmentedBar.selectedIndex];
        this.terminalID = segmentedBar.selectedIndex + 1;
    }
    public onSelectedIndexChange(args) {
        let segmentedBar = <SegmentedBar>args.object;
        this.status = this.s[segmentedBar.selectedIndex];
    }

    ngOnInit() {
        this.page.actionBarHidden = true;
    }

    back() {
        this.router.navigate(["/admin"]);
    }
}

