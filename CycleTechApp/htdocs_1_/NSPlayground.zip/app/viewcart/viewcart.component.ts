import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { CartComponent } from "../shared/cartfunctions";


@Component({
    selector: "gr-viewcart",
    providers: [UserService, CartComponent],
    styleUrls: ["app.css"],
    templateUrl: "viewcart/viewcart.component.xml"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})

export class ViewCartComponent implements OnInit {
    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
        this.user = new User();
    }
    back() {
        // alert();
        this.router.navigate(["/terminal"]);
    }
    checkout() {

        this.router.navigate(["/from"]);
    }
    ngOnInit() {
        this.page.actionBarHidden = true;

        var c = 0;
        let stacktemp;
        let labeltemp;
        let parent = <StackLayout>getViewById(this.page, "stack");
        if (parent) {
            while (Config.order[c] != null) {
                stacktemp = <StackLayout>new StackLayout();
                stacktemp.orientation = "horizontal";
                stacktemp.width = "100%";
                var stackt2 = <StackLayout>new StackLayout();
                stackt2.orientation = "vertical";
                stackt2.width = 50;
                labeltemp = <Label>new Label();
                var cs = Config.order[c]["Make"];
                labeltemp.text = cs;
                labeltemp.width = "20%";
                stacktemp.addChild(labeltemp);
                labeltemp = <Label>new Label();
                cs = Config.order[c]["Model"];
                labeltemp.text = cs;
                labeltemp.width = "30%";
                stacktemp.addChild(labeltemp);
                cs = Config.order[c]["Color"];
                labeltemp = <Label>new Label();
                labeltemp.text = cs;
                labeltemp.width = "20%";
                stacktemp.addChild(labeltemp);
                cs = " " + Config.bikes[c]["Price"];
                labeltemp = <Label>new Label();
                labeltemp.text = cs;
                labeltemp.width = "10%";
                stacktemp.addChild(labeltemp);
                labeltemp = <Button>new Button();
                labeltemp.text = "-";
                labeltemp.value = Config.order[c];
                labeltemp.class = "btn-primary";
                // labeltemp.width = "30%";
                labeltemp.on(Button.tapEvent, (data: EventData) => {
                    // this.buttonTap(data.object.get("value"));
                    var s = <Button>data.object;
                    // alert(JSON.stringify(data.object.get("value")));
                    if (data.object.get("text") == "-") {
                        this.cart.cartRemove(data.object.get("value"));
                    }
                });
                stacktemp.addChild(labeltemp);
                parent.addChild(stacktemp);
                c++;
            }
        }

    }
}