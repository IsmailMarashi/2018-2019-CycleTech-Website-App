import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { CartComponent } from "../shared/cartfunctions";
import { Color } from "tns-core-modules/color";
import { GridLayout, GridUnitType, ItemSpec } from "tns-core-modules/ui/layouts/grid-layout";
import { SegmentedBar, SegmentedBarItem } from "tns-core-modules/ui/segmented-bar";
import { ChangeDetectionStrategy } from "@angular/core";


@Component({
    selector: "gr-viewbike",
    providers: [UserService, CartComponent],
    styleUrls: ["./app.css"],
    templateUrl: "viewbike/viewbike.component.xml"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})

export class ViewBikeComponent implements OnInit {
    textFieldValue: string = "";
    status: String = new String("");
    make: String = new String("");
    model: String = new String("");
    color: String = new String("");
    id: String = new String("");

    s: Array<String> = ["Servicing", "Available", "Broken", "Pending", "In-use"];
    private getSegmentedBarItems = () => {
        let sb1 = new SegmentedBarItem();
        sb1.title = <string>this.s[0];
        let sb2 = new SegmentedBarItem();
        sb2.title = <string>this.s[1];
        let sb3 = new SegmentedBarItem();
        sb3.title = <string>this.s[2];
        let sb4 = new SegmentedBarItem();
        sb4.title = <string>this.s[3];
        let sb5 = new SegmentedBarItem();
        sb5.title = <string>this.s[4];
        return [sb1, sb2, sb3, sb4, sb5];
    }
    segmentedBarItems: Array<SegmentedBarItem> = this.getSegmentedBarItems();
    selectedBarIndex: number = 0;
    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
        this.user = new User();
    }
    back() {
        this.router.navigate(["/admin"]);
    }

    submit() {
        if (this.color != null && this.id != null && this.make != null && this.model != null) {
            this.cart.bikestate(this.id, this.status).subscribe();
        }
        else {
            alert("A null error occured try again later.");
        }
    }

    public onSelectedIndexChange(args) {
        let segmentedBar = <SegmentedBar>args.object;
        this.status = this.s[segmentedBar.selectedIndex];
    }




    ngOnInit() {
        this.page.actionBarHidden = true;
        Config.bikes = null;
        this.cart.viewbike().subscribe(() => {
            var c = 0;
            let stacktemp;
            let labeltemp;
            let parent = <StackLayout>getViewById(this.page, "stack");
            this.status = Config.bikes[0]['Status'];
            this.make = Config.bikes[0]['Make'];
            this.model = Config.bikes[0]['Model'];
            this.color = Config.bikes[0]['Color'];
            this.id = Config.bikes[0]['BikeID'];
            if (parent) {
                while (Config.bikes[c] != null) {
                    stacktemp = <StackLayout>new StackLayout();
                    stacktemp.value = Config.bikes[c];
                    stacktemp.on(Button.tapEvent, (data: EventData) => {
                        var s = <JSON>data.object.get("value");
                        this.status = s['Status'];
                        this.make = s['Make'];
                        this.model = s['Model'];
                        this.color = s['Color'];
                        this.id = s['BikeID'];
                        var l = <Label>getViewById(this.page, "id");
                        l.text = "" + this.id;
                        l = <Label>getViewById(this.page, "make");
                        l.text = "" + this.make;
                        l = <Label>getViewById(this.page, "model");
                        l.text = "" + this.model;
                        l = <Label>getViewById(this.page, "color");
                        l.text = "" + this.color;
                        l = <Label>getViewById(this.page, "status");
                        l.text = "" + this.status;
                        var sa = <SegmentedBar>getViewById(this.page, "bar");
                        sa.selectedIndex = this.s.indexOf(this.status);
                    });
                    stacktemp.orientation = "horizontal";
                    stacktemp.width = "100%";
                    labeltemp = <Label>new Label();
                    var cs = Config.bikes[c]["BikeID"];
                    labeltemp.text = cs;
                    labeltemp.width = "10%";
                    // labeltemp.TextAlignment = "left";
                    stacktemp.addChild(labeltemp);
                    labeltemp = <Label>new Label();
                    cs = Config.bikes[c]["Make"];
                    labeltemp.text = cs;
                    labeltemp.width = "20%";
                    stacktemp.addChild(labeltemp);
                    labeltemp = <Label>new Label();
                    cs = Config.bikes[c]["Model"];
                    labeltemp.text = cs;
                    labeltemp.width = "35%";
                    stacktemp.addChild(labeltemp);

                    cs = Config.bikes[c]["Color"];
                    labeltemp = <Label>new Label();
                    labeltemp.text = cs;
                    labeltemp.width = "15%";
                    stacktemp.addChild(labeltemp);
                    cs = " " + Config.bikes[c]["Status"];
                    labeltemp = <Label>new Label();
                    labeltemp.text = cs;
                    labeltemp.width = "20%";
                    stacktemp.addChild(labeltemp);

                    parent.addChild(stacktemp);
                    c++;
                }
            }
        },
            () => alert("Unfortunately we were unable fetch bikes from the server."));
    }





}