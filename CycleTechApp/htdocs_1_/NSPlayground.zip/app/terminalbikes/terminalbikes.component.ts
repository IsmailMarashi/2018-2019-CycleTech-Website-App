import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { CartComponent } from "../shared/cartfunctions";
import { Color } from "tns-core-modules/color";
import { GridLayout, GridUnitType, ItemSpec } from "tns-core-modules/ui/layouts/grid-layout";
import { SegmentedBar, SegmentedBarItem } from "tns-core-modules/ui/segmented-bar";
import { ChangeDetectionStrategy } from "@angular/core";


@Component({
    selector: "gr-terminalbikes",
    providers: [UserService, CartComponent],
    styleUrls: ["./app.css"],
    templateUrl: "terminalbikes/terminalbikes.component.xml"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})

export class TerminalBikesComponent implements OnInit {



    s: Array<String> = ["Alexei", "Kata", "Toinette", "Sheridan", "Osborn"];
    private getSegmentedBarItems = () => {
        let sb1 = new SegmentedBarItem();
        sb1.title = <string>this.s[0];
        let sb2 = new SegmentedBarItem();
        sb2.title = <string>this.s[1];
        let sb3 = new SegmentedBarItem();
        sb3.title = <string>this.s[2];
        let sb4 = new SegmentedBarItem();
        sb4.title = <string>this.s[3];
        let sb5 = new SegmentedBarItem();
        sb5.title = <string>this.s[4];
        return [sb1, sb2, sb3, sb4, sb5];
    }
    segmentedBarItems: Array<SegmentedBarItem> = this.getSegmentedBarItems();
    selectedBarIndex: number = 0;
    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
        this.user = new User();
    }
    back() {
        this.router.navigate(["/admin"]);
    }

    submit() {

    }

    public onSelectedIndexChange(args) {
        let segmentedBar = <SegmentedBar>args.object;
        let parent = <StackLayout>getViewById(this.page, "stack");
        this.cart.terminalbikes(segmentedBar.selectedIndex+1).subscribe(() => { this.loadparent(parent) });
    }
    loadparent(parent: StackLayout) {
        parent.removeChildren();
        var c = 0;
        let stacktemp;
        let labeltemp;

        if (parent) {
            while (Config.bikes[c] != null) {

                stacktemp = <StackLayout>new StackLayout();


                stacktemp.orientation = "horizontal";
                stacktemp.width = "100%";
                labeltemp = <Label>new Label();
                var cs = Config.bikes[c]["BikeID"];
                labeltemp.text = cs;
                labeltemp.width = "10%";
                // labeltemp.TextAlignment = "left";
                stacktemp.addChild(labeltemp);
                labeltemp = <Label>new Label();
                cs = Config.bikes[c]["Make"];
                labeltemp.text = cs;
                labeltemp.width = "20%";
                stacktemp.addChild(labeltemp);
                labeltemp = <Label>new Label();
                cs = Config.bikes[c]["Model"];
                labeltemp.text = cs;
                labeltemp.width = "30%";
                stacktemp.addChild(labeltemp);

                cs = Config.bikes[c]["Color"];
                labeltemp = <Label>new Label();
                labeltemp.text = cs;
                labeltemp.width = "15%";
                stacktemp.addChild(labeltemp);
                cs = " " + Config.bikes[c]["Status"];
                labeltemp = <Label>new Label();
                labeltemp.text = cs;
                labeltemp.width = "20%";
                stacktemp.addChild(labeltemp);
                parent.addChild(stacktemp);
                c++;

            }
        }
    }



    ngOnInit() {
        this.page.actionBarHidden = true;
         
        
    }





}