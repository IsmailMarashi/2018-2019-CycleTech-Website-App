import * as geoLocation from "nativescript-geolocation";
import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { CartComponent } from "../shared/cartfunctions";
import { isEnabled, enableLocationRequest, getCurrentLocation, watchLocation, distance, clearWatch } from "nativescript-geolocation";


@Component({
    selector: "gr-bikeEMU",
    providers: [UserService, CartComponent],
    styleUrls: ["app.css"],
    templateUrl: "bikeEMU/bikeEMU.component.xml"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})



export class BikeEMUComponent implements OnInit {
    currentGeoLocation: any;
    watchId: any;
    latitude: any = "0";
    longitude: any = "0";

    enableLocationServices(): void {
        geoLocation.isEnabled().then(enabled => {
            if (!enabled) {
                geoLocation.enableLocationRequest().then(() => this.showLocation());
            } else {
                this.showLocation();
            }
        });
    }

    showLocation(): void {
        geoLocation.watchLocation(location => {
            console.log(this.currentGeoLocation);
            this.currentGeoLocation = location;
        }, error => {
            alert(error);
        }, {
                desiredAccuracy: 1,
                updateDistance: 0,
                minimumUpdateTime: 1
            });
    }

    buttonStartTap() {

        this.watchId = watchLocation(
            function (loc) {
                if (loc) {
                    console.log("Received location: " + "LAT: " + loc.latitude + " LONG:" + loc.longitude);
                }
            },
            function (e) {
                console.log("Error: " + e.message);
            },
            { desiredAccuracy: 1, updateDistance: 0, minimumUpdateTime: 1 * 1 }); // Should update every 20 seconds according to Googe documentation. Not verified.
    }

    buttonStopTap() {
        if (this.watchId) {
            clearWatch(this.watchId);
        }
    }



    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
        this.user = new User();
    }

    back() {

        this.router.navigate(["/admin"]);
    }
    ngOnInit() {
        this.page.actionBarHidden = true;
        this.enableLocationServices();
        this.buttonStartTap();
    }
}