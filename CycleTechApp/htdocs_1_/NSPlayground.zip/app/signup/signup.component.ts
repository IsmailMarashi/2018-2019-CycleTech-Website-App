import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";

@Component({
    selector: "gr-signup",
    providers: [UserService],
    templateUrl: "signup/signup.component.html",
    styleUrls: ["app.css"],
})
export class SignupComponent implements OnInit {
    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page) {
        this.user = new User();
        this.user.email = "ism.marashi@gmail.com";
        this.user.password = "testpass";
        this.user.first = "Ismail";
        this.user.last = "Marashi";
        this.user.phone = +971564277066;
        this.user.address = "some address";
    }
    signup() {
        //this.router.navigate(["/home"]);
        this.userService.register(this.user).subscribe(
            () => {
                // alert("Your account was successfully created.");
            }//, () => alert("Unfortunately we were unable to create your account.")
        );
    }


    ngOnInit() {
        this.page.actionBarHidden = true;
    }
    back() {
        this.router.navigate([""]);
    }
}

