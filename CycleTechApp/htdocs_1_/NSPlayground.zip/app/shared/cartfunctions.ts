import { UserService } from "../shared/user/user.service";
import { Page } from "tns-core-modules/ui/page";
import { AppModule } from '../app.module';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { Injectable } from "@angular/core";
import { Http, Headers, Response } from "@angular/http";
import { Observable, throwError } from "rxjs";
import { catchError, map, tap } from "rxjs/operators";
import { request, getFile, getImage, getJSON, getString } from "tns-core-modules/http";
import { User } from "./user/user.model";
import { Config } from "./config";
import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';






@Component({
    selector: "gr-cart",
    providers: [UserService]
})

@Injectable()
export class CartComponent {


    constructor(
        private http: Http, private router: Router) {

    }

    cartAdd(item: JSON) {
        if (this.cartExists(item) == -1) {
            Config.order.push(item);
        }
        console.log(this.cartString());
    }

    cartRemove(item: JSON) {



       
        var sd = Config.order.length;
        var ss = new Array<JSON>();
        var c = 0;
        while (c < sd) {
            if (item["BikeID"] != Config.order[c]["BikeID"]) {
                ss.push(Config.order[c]);
            }
            c++
        }
        // console.log(Config.order.length + ": " + this.cartString());
        Config.order = ss;
    }

    // if (Config.order.length > 0) {
    //     Config.order[i] = s;
    // }
    // else {
    //     Config.order = new Array<JSON>();
    // }
    // console.log(Config.order.length + ": " + this.cartString());
    //     }
    // }

    cartString() {
        var s = "";
        for (var i = 0; i < Config.order.length; i++) {
            // s = s + JSON.stringify(this.cart[i]);
            s = s + Config.order[i]["Model"] + "  |  ";
        }
        return s;
    }

    cartExists(item: JSON) {
        for (var i = 0; i < Config.order.length; i++) {
            if (item["BikeID"] == Config.order[i]["BikeID"]) {
                return i;
            }
        }
        return -1;
    }


    submitOrder() {
        return this.http.post(
            Config.apiUrl + "/submitOrder.php",
            JSON.stringify({
                order: Config.order,
                id: Config.cuser.id,
                start: Config.startTime,
                end: Config.endTime,
                total: Config.total,
            }), { headers: this.getCommonHeaders() }).pipe(map(response => response.json()),
                tap(data => {
                    console.log(data);
                    if (data.status == "success") {
                        alert("Your booking was successful ");
                        return 1;
                    }
                    else {
                        if (data.status == "error") {
                            alert("Booking Error: Booking Unsuccessful");
                            return -1;
                        }
                        else {
                            alert("Unknown Error: " + data.status);
                            return -1;
                        }
                    }
                }),
                // catchError(this.handleErrors)
            );
    }

    getTimeDiff() {
        return this.http.post(
            Config.apiUrl + "/getTimeDiff.php",
            JSON.stringify({
                tFrom: Config.startTime
                , tTo: Config.endTime
            }), { headers: this.getCommonHeaders() }).pipe(map(response => response.json()),
                tap(data => {
                    // console.log(data.status);
                    if (data.status == "success") {
                        Config.timediff = data.q;
                        if (Config.timediff < 1) {
                            alert("The time difference between " + Config.startTime + " and " + Config.endTime + " is negative or zero. Try again. ");
                            this.router.navigate(["/from"]);
                        };
                        return 1;
                    }
                    else {
                        if (data.status == "error") {
                            alert("Calulation Error: no result");
                            return -1;
                        }
                        else {
                            alert("Calulation Error: " + data.status);
                            return -1;
                        }
                    }
                }),
                // catchError(this.handleErrors)
            );
    }

    submitComplaint(receiptIDs: number, complaintt: string) {
        return this.http.post(
            Config.apiUrl + "/submitcomplaint.php",
            JSON.stringify({
                receiptID: receiptIDs,
                complaint: complaintt
            }), { headers: this.getCommonHeaders() }).pipe(map(response => response.json()),
                tap(data => {
                    console.log(data);
                    if (data.status == "success") {
                        alert("Complaint was successfully submitted.");
                        return 1;
                    }
                    else {
                        if (data.status == "Fail") {
                            alert("Complaint Error: Failed to submit complaint");
                            return -1;
                        }
                        else {
                            alert("Unknown Error: " + data.status);
                            return -1;
                        }
                    }
                }),
                // catchError(this.handleErrors)
            );
    }
    addbike(make1, model1, color1, terminal1, terminalID1, status1, price1, amount1) {
        return this.http.post(
            Config.apiUrl + "/addbike.php",
            JSON.stringify({
                make: make1,
                model: model1,
                color: color1,
                terminal: terminal1,
                terminalID: terminalID1,
                status: status1,
                price: price1,
                amount: amount1
            }), { headers: this.getCommonHeaders() }).pipe(map(response => response.json()),
                tap(data => {
                    console.log(data);
                    if (data.status == "success") {
                        alert("bike(s) added successfully.");
                        return 1;
                    }
                    else {
                        if (data.status == "Fail") {
                            alert("Bike Adding Error: Failed to added bikes");
                            return -1;
                        }
                        else {
                            alert("Unknown Error: " + data.status);
                            return -1;
                        }
                    }
                }),
                // catchError(this.handleErrors)
            );
    }


    viewbike() {
        return this.http.post(
            Config.apiUrl + "/viewbike.php",
            "", { headers: this.getCommonHeaders() }).pipe(map(response => response.json()),
                tap(data => {
                    console.log(data.status);
                    if (data.status == "success") {
                        console.log("bike(s) Loaded successfully.");
                        Config.bikes = data.bikes;
                        return 1;
                    }
                    else {
                        if (data.status == "Fail") {
                            alert("Bike Loading Error: Failed to load bikes");
                            return -1;
                        }
                        else {
                            alert("Unknown Error: " + data.status);
                            return -1;
                        }
                    }
                }),
                // catchError(this.handleErrors)
            );
    }

    bikestate(idd, state) {
        return this.http.post(
            Config.apiUrl + "/bikestate.php",
            JSON.stringify({
                id: idd,
                status: state
            }), { headers: this.getCommonHeaders() }).pipe(map(response => response.json()),
                tap(data => {
                    console.log(data);
                    if (data.status == "success") {
                        alert("Bike state changed successfully.");
                        return 1;
                    }
                    else {
                        if (data.status == "Fail") {
                            alert("Bike Status Error: Failed to change bike state");
                            return -1;
                        }
                        else {
                            alert("Unknown Error: " + data.status);
                            return -1;
                        }
                    }
                }),
                // catchError(this.handleErrors)
            );
    }

    bookings() {
        return this.http.post(
            Config.apiUrl + "/viewbook.php",
            JSON.stringify({}),
            { headers: this.getCommonHeaders() }
        ).pipe(
            map(response => response.json()),
            tap(data => {
                if (data.status == "success") {
                    // alert("test");

                    Config.receipts = data.receipts;
                    // alert("test");
                    return 1;
                }
                else {
                    if (data.status == "No reciepts") {
                        alert("Failed to fetch receipts");
                        // return throwError("Login Failed: No user with that login and password exists.");
                        return -1;
                    }
                    else {
                        alert("Fetchings Receipts Failed: " + data.status);
                        return -1;
                    }
                }
            }),
            // catchError(this.handleErrors)
        );
    }

    complaints(idd) {
        return this.http.post(
            Config.apiUrl + "/rcomplaints.php",
            JSON.stringify({
                id: idd
            }), { headers: this.getCommonHeaders() }).pipe(map(response => response.json()),
                tap(data => {
                    // console.log(data);
                    if (data.status == "success") {
                        alert("Complaints fetched successfully.");
                        Config.complaints = data.complaints;
                        return 1;
                    }
                    else {
                        if (data.status == "Fail") {
                            alert("Complaint fetch Error: Failed to fetch complaints");
                            return -1;
                        }
                        else {
                            alert("Unknown Error: " + data.status);
                            return -1;
                        }
                    }
                }),
                // catchError(this.handleErrors)
            );
    }

    cancelOrder(idd) {
        return this.http.post(
            Config.apiUrl + "/deleteOrder.php",
            JSON.stringify({
                id: idd
            }), { headers: this.getCommonHeaders() }).pipe(map(response => response.json()),
                tap(data => {
                    console.log(data);
                    if (data.status == "success") {
                        alert("Order successfully cancelled.");
                        return 1;
                    }
                    else {
                        if (data.status == "Fail") {
                            alert("Order cancellation Error: Failed to cancel order");
                            return -1;
                        }
                        else {
                            alert("Unknown Error: " + data.status);
                            return -1;
                        }
                    }
                }),
                // catchError(this.handleErrors)
            );
    }
    refresh(page) {
        this.router.navigate([page]);
    }

    terminalbikes(tid) {

        return this.http.post(
            Config.apiUrl + "/tbikes.php",
            JSON.stringify({
                id: tid
            }), { headers: this.getCommonHeaders() }).pipe(map(response => response.json()),
                tap(data => {
                    console.log(data);
                    if (data.status == "success") {
                        Config.bikes = data.bikes;
                        // alert("Terminal bikes successfully fetched.");
                        return 1;
                    }
                    else {
                        if (data.status == "No bikes") {
                            alert("Terminal Fetch Error: No bikes at terminal");
                            return -1;
                        }
                        else {
                            alert("Unknown Error: " + data.status);
                            return -1;
                        }
                    }
                }),
                // catchError(this.handleErrors)
            );
    }


    getCommonHeaders() {
        let headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Authorization", Config.authHeader);
        return headers;
    }
    handleErrors(error: Response) {
        console.log(JSON.stringify(error.json()));
        return Observable.throw(error);
    }
}