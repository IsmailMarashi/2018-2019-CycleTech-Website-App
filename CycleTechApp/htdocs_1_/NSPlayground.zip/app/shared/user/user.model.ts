export class User {
    id: string;
    first: string;
    last: string;
    email: string;
    phone: number;
    address: string;
    password: string;
    typet: string;
}