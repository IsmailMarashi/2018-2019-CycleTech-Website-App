import { Injectable } from "@angular/core";
import { Http, Headers, Response } from "@angular/http";
import { Observable, throwError } from "rxjs";
import { catchError, map, tap } from "rxjs/operators";
import { request, getFile, getImage, getJSON, getString } from "tns-core-modules/http";
import { User } from "./user.model";
import { Config } from "../config";
import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';





@Injectable()
export class UserService {
    constructor(
        private http: Http, private router: Router) {
        Config.cuser.id = "38";//------------------------------------------
        Config.cuser.first = "Lài";
        Config.cuser.last = "Pendry";
        Config.cuser.email = "ISM@ISM.com";
        Config.cuser.phone = 2147483647;
        Config.cuser.address = "3 School Parkway";
        Config.cuser.password = "ebf2434107ddd21c709a";
        Config.cuser.typet = "admin";
    }

    login(user: User) {
        if (!user.email || !user.password) {
            return throwError("Please provide both an email address and password.");
        }
        return this.http.post(
            Config.apiUrl + "/login.php",
            JSON.stringify({
                email: user.email,
                password: user.password
            }),
            { headers: this.getCommonHeaders() }
        ).pipe(
            map(response => response.json()),
            tap(data => {
                console.log(data.status);
                if (data.status == "success") {
                    console.log("ID: " + data.id + "\n" + "First: " + data.first + "\n" + "Last: " + data.last + "\n" + "Email: " + data.email + "\n" + "Pass: " + data.password + "\n" + "Phone: " + data.phonenumber + "\n" + "Address: " + data.address);
                    // alert("Login Success");
                    user.id = data.id;
                    user.first = data.first;
                    user.last = data.last;
                    user.email = data.email;
                    user.password = data.password;
                    user.phone = data.phonenumber;
                    user.address = data.address;
                    user.typet = data.typet;
                    Config.cuser = user;
                    // alert(Config.cuser.id + "\n" + Config.cuser.first + "\n" + Config.cuser.last + "\n" + Config.cuser.email + "\n" + Config.cuser.password + "\n" + Config.cuser.phonenumber + "\n" + Config.cuser.address + "\n" + Config.cuser.typet);
                    this.router.navigate(["/home"]);
                    return 1;
                }
                else {
                    if (data.status == "NoLogin") {
                        alert("Login Failed: No user with that login and password exists.");
                        // return throwError("Login Failed: No user with that login and password exists.");
                        return -1;
                    }
                    else {
                        alert("Login Failed: " + data.status);
                        return -1;
                    }
                }
            }),
            // catchError(this.handleErrors)
        );

    }

    register(user: User) {
        if (!user.email || !user.password) {
            return throwError("Please provide both an email address and password.");
        }

        return this.http.post(
            Config.apiUrl + "/register.php",
            JSON.stringify({
                first: user.first,
                last: user.last,
                email: user.email,
                password: user.password,
                phone: user.phone,
                address: user.address,
                typet: "normal"
            }),
            { headers: this.getCommonHeaders() }
        ).pipe(
            map(response => response.json()),
            tap(data => {
                if (data.status == "success") {
                    alert("Registration Success");
                    this.router.navigate([""]);
                }
                else {
                    alert("Registration Failed: " + data.status);
                }
            }),
            catchError(this.handleErrors)
        );
    }

    getTerminals(terminal: Config) {

        return this.http.post(
            Config.apiUrl + "/terminal.php", "test").pipe(
                map(response => response.json()),
                tap(data => {

                    if (data.status == "success") {

                        Config.terminal = data.terminals;

                        // console.log(Config.terminal[1].name);
                        // this.router.navigate([""]);
                    }
                    else {
                        alert("Failed: " + data.status);
                    }
                }),
                catchError(this.handleErrors)
            );
    }
    getReceipts(receipts: Config) {
        return this.http.post(
            Config.apiUrl + "/receipts.php",
            JSON.stringify({
                id: Config.cuser.id,
                // password: Config.cuser.password
            }),
            { headers: this.getCommonHeaders() }
        ).pipe(
            map(response => response.json()),
            tap(data => {
                if (data.status == "success") {
                    // alert("test");

                    Config.receipts = data.receipts;
                    // alert("test");
                    return 1;
                }
                else {
                    if (data.status == "NoLogin") {
                        alert("Login Failed: No user with that login and password exists.");
                        // return throwError("Login Failed: No user with that login and password exists.");
                        return -1;
                    }
                    else {
                        alert("Login Failed: " + data.status);
                        return -1;
                    }
                }
            }),
            // catchError(this.handleErrors)
        );


    }



    getBikes(bikes: Config) {
        return this.http.post(
            Config.apiUrl + "/bikes.php",
            JSON.stringify({ terminal: Config.destination }),
            { headers: this.getCommonHeaders() }
        ).pipe(
            map(response => response.json()),
            tap(data => {
                if (data.status == "success") {
                    Config.bikes = data.bikes;
                }
                else if (data.status = "No bikes") {
                    alert(data.status + "available at " + Config.destination);
                }
                else {
                    alert("Failed: " + data.status);
                }
            }),
            catchError(this.handleErrors)
        );
    }








    getCommonHeaders() {
        let headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Authorization", Config.authHeader);
        return headers;
    }

    handleErrors(error: Response) {
        console.log(JSON.stringify(error.json()));
        return Observable.throw(error);
    }
}