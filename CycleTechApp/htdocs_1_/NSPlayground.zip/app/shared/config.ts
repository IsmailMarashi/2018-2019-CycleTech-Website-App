import { User } from "./user/user.model";

export class Config {
  static apiUrl = "http://192.168.1.117";
  static appKey = "kid_HyHoT_REf";
  static authHeader = "Basic a2lkX0h5SG9UX1JFZjo1MTkxMDJlZWFhMzQ0MzMyODFjN2MyODM3MGQ5OTIzMQ";
  static token = "";
  static cuser = new User();
  static order = new Array<JSON>();
  static receipts = new Array<JSON>();
  static destination;
  static terminal;
  static bikes;
  static pReceipt;
  static receiptID;
  static startTime;
  static endTime;
  static timediff;
  static total;
  static complaints = new Array<JSON>();
}
