import { Component, OnInit } from "@angular/core";
import { User } from "../../shared/user/user.model";
import { UserService } from "../../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../../app.module';
import { Config } from '../../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { CartComponent } from "../../shared/cartfunctions";
import { DatePicker } from "tns-core-modules/ui/date-picker";
import { TimePicker } from "tns-core-modules/ui/time-picker";

@Component({
    selector: "gr-from",
    providers: [UserService, CartComponent],
    styleUrls: ["checkout/from/from.component.css"],
    templateUrl: "checkout/from/from.component.html"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})

export class FromComponent implements OnInit {


    user: User;
    datetime: Date = new Date();
    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
        this.user = new User();
    }
    back() {
        this.router.navigate(["/viewcart"]);
    }
    next() {
        this.router.navigate(["/to"]);
    }
    ngOnInit() {
        this.page.actionBarHidden = true;
        this.datetime.setFullYear(new Date().getFullYear());
        this.datetime.setMonth(new Date().getMonth());
        this.datetime.setDate(new Date().getDate());
        this.datetime.setHours(new Date().getHours());
        this.datetime.setMinutes(new Date().getMinutes());
        Config.startTime = this.datetime.getFullYear() + "-" + this.datetime.getMonth() + "-" + this.datetime.getDay() + " " + this.datetime.getHours() + ":" + this.datetime.getMinutes() + ":00";
    }
    timeLoaded(args) {
        let timePicker = <TimePicker>args.object;
        args = this.datetime;
    }
    dateLoaded(args) {
        let datePicker = <DatePicker>args.object;
        args = this.datetime;
        datePicker.minDate = this.datetime;
        datePicker.maxDate = new Date(2020, 4, 12);
    }
    timeChanged(args) {
        let timePicker = <TimePicker>args.object;
        this.datetime.setHours(timePicker.hour);
        this.datetime.setMinutes(timePicker.minute);
        Config.startTime = this.datetime.getFullYear() + "-" + this.datetime.getMonth() + "-" + this.datetime.getDay() + " " + this.datetime.getHours() + ":" + this.datetime.getMinutes() + ":00";
    }
    dateChanged(args) {
        let datePicker = <DatePicker>args.object;
        this.datetime.setFullYear(datePicker.year);
        this.datetime.setMonth(datePicker.month);
        this.datetime.setDate(datePicker.day);
        Config.startTime = this.datetime.getFullYear() + "-" + this.datetime.getMonth() + "-" + this.datetime.getDay() + " " + this.datetime.getHours() + ":" + this.datetime.getMinutes() + ":00";
    }
}