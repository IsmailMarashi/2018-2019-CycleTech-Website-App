import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";

@Component({
    selector: "gr-login",
    providers: [UserService],
    styleUrls: ["login/login.component.css"],
    templateUrl: "login/login.component.html"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})

export class LoginComponent implements OnInit {
    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page) {
        this.user = new User();
        this.user.email = "ISM@ISM.com";
        this.user.password = "ebf2434107ddd21c709a";
    }
    ngOnInit() {
        this.page.actionBarHidden = true;
    }
    login() {

        this.userService.login(this.user).subscribe(
            // user => this.user = user,
            // (error) =>  alert("error")
            // ,
            // () => this.router.navigate(["/home"])
        );
    }
    signup() { this.router.navigate(["/signup"]) }
}