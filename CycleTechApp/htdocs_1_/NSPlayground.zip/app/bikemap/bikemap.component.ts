import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { Observable } from 'rxjs';
import { CartComponent } from "../shared/cartfunctions";
import { WebView } from "tns-core-modules/ui/web-view";


@Component({
    selector: "gr-bikemap",
    providers: [UserService, CartComponent],
    styleUrls: ["app.css"],
    templateUrl: "bikemap/bikemap.component.xml"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})




export class BikeMapComponent implements OnInit {
    lv: string = Config.apiUrl + "/mbikes.html";
    count = 0;
    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
        this.user = new User();
    }
    ngOnInit() {
        this.page.actionBarHidden = true;
         
    }
    back() {
        // alert();
        this.router.navigate(["/admin"]);
    }

}