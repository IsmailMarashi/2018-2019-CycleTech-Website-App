import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { Observable } from 'rxjs';
import { CartComponent } from "../shared/cartfunctions";
import { WebView } from "tns-core-modules/ui/web-view";


@Component({
    selector: "gr-admin",
    providers: [UserService, CartComponent],
    styleUrls: ["app.css"],
    templateUrl: "admin/admin.component.xml"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})




export class AdminComponent implements OnInit {
    onButtonTap(): void {
        console.log("Button was pressed");
    }

    count = 0;

    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {

    }
    ngOnInit() {
        this.page.actionBarHidden = true;

    }
    back() {
        // alert();
        this.router.navigate(["/home"]);
    }
    addbike() {
        this.router.navigate(["/addbike"]);
    }
    bike() {
        this.router.navigate(["/bikemap"]);
    }

    terminalbikes() {
        this.router.navigate(["/terminalbikes"]);
    }
    viewbike() {
        this.router.navigate(["/viewbike"]);
    }

    bookings() {
        this.router.navigate(["/bookings"]);
    }
    bikeemu() {
        this.router.navigate(["/bikeEMU"]);
    }




}