



import { Button } from "tns-core-modules/ui/button";
import { EventData } from "tns-core-modules/data/observable";
import { Label } from "tns-core-modules/ui/label";



import { CartComponent } from "../shared/cartfunctions";
import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";

import { getViewById } from "tns-core-modules/ui/core/view";

import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";

import { View } from "tns-core-modules/ui/core/view";
import { Observable } from 'rxjs';



@Component({
    selector: "gr-home",
    providers: [UserService],
    templateUrl: "home/home.component.xml",
    styleUrls: ["home/home.component.css"]
})
export class HomeComponent implements OnInit {
    onButtonTap(): void {
        console.log("Button was pressed");
    }


    constructor(private router: Router, private userService: UserService, private page: Page) {
    }

    ngOnInit() {
        this.page.actionBarHidden = true;
        // console.log(Config.cuser);





    }

    userinfo() {
        this.router.navigate(["/userinfo"]);
    }
    logout() {
        console.log("logging");
        this.router.navigate([""]);
    }

    bookings() {
        this.router.navigate(["./receipts"]);
    }
    booknow() {
        this.router.navigate(["./terminal"]);
    }
    admin() {

        if (Config.cuser.typet == "admin") {

            this.router.navigate(["./admin"]);
        }
        if (Config.cuser.typet != "admin") {
            alert("admin privileges required");
        }

    }
}

