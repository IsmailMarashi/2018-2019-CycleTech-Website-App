import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { Observable } from 'rxjs';
import { CartComponent } from "../shared/cartfunctions";
import { WebView } from "tns-core-modules/ui/web-view";


@Component({
    selector: "gr-terminal",
    providers: [UserService, CartComponent],
    styleUrls: ["app.css"],
    templateUrl: "terminal/terminal.component.xml"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})




export class TerminalComponent implements OnInit {
    lv: string = Config.apiUrl + "/m.html";
    count = 0;
    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
        this.user = new User();
    }
    ngOnInit() {
        this.page.actionBarHidden = true;
        this.userService.getTerminals(Config.terminal).subscribe(() => {
            var c = 0;
            let stacktemp;
            let labeltemp;
            let parent = <StackLayout>getViewById(this.page, "stack");
            let sss = this.page;
            // sss.set("album", this.album);
            if (parent) {
                while (Config.terminal[c] != null) {
                    stacktemp = <StackLayout>new StackLayout();
                    stacktemp.orientation = "horizontal";
                    // stacktemp.backgroundColor = "gray";
                    // stacktemp.Align = "center";
                    // stacktemp.width = "100%"  ;
                    stacktemp.borderRadius = 10;
                    stacktemp.margin = 2;
                    var s = Config.terminal[c]["Terminal"];
                    // console.log(s);
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "33%";
                    stacktemp.addChild(labeltemp);
                    labeltemp = <Label>new Label();
                    var cs = Config.terminal[c]["NumOfBicycle"];
                    labeltemp.text = cs;
                    labeltemp.textAlign = "center";
                    labeltemp.width = "33%";
                    stacktemp.addChild(labeltemp);
                    labeltemp = <Button>new Button();
                    labeltemp.text = "Book";
                    labeltemp.value = s;
                    labeltemp.borderRadius = 10;
                    if (cs == 0)
                        labeltemp.on(Button.tapEvent, (data: EventData) => {
                            alert(data.object.get("value") + " has no bikes you can book");
                        });
                    else labeltemp.on(Button.tapEvent, (data: EventData) => {
                        // this.buttonTap(data.object.get("value"));
                        Config.destination = data.object.get("value");
                        this.router.navigate(["/book"]);
                    });
                    labeltemp.class = "btn-primary";
                    labeltemp.width = "33%";
                    stacktemp.addChild(labeltemp);
                    parent.addChild(stacktemp);
                    c++;
                }
            }

        },
            () => alert("Unfortunately we were unable fetch all the terminals."));
    }
    back() {
        // alert();
        this.router.navigate(["/home"]);
    }

}