import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Config } from "../shared/config";
@Component({
    selector: "gr-userinfo",
    providers: [UserService],
    templateUrl: "userinfo/userinfo.component.html",
    styleUrls: ["app.css"],
})
export class UserinfoComponent implements OnInit {
    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page) {
        this.user = Config.cuser;
    }
    back() {
        this.router.navigate(["/home"]);
    }
    ngOnInit() {
        this.page.actionBarHidden = true;
    }
    update() {
        alert("Not implemented");
    }
}

