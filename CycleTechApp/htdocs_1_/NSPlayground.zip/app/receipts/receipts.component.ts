import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { CartComponent } from "../shared/cartfunctions";


@Component({
    selector: "gr-receipts",
    providers: [UserService, CartComponent],
    styleUrls: ["receipts/receipts.component.css"],
    templateUrl: "receipts/receipts.component.xml"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})

export class ReceiptsComponent implements OnInit {

    // buttonTap(s: JSON) {
    //     // alert(JSON.stringify(s));

    // }

    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
        this.user = new User();
    }
    back() {
        // alert();
        this.router.navigate(["/home"]);
    }
    ngOnInit() {
        this.page.actionBarHidden = true;

        this.userService.getReceipts(Config.receipts).subscribe(() => {
            var c = 0;
            let stacktemp;
            let stack;
            let labeltemp;
            let parent = <StackLayout>getViewById(this.page, "stack");
            if (parent) {
                while (Config.receipts[c] != null) {
                    stacktemp = <StackLayout>new StackLayout();
                    stack = <StackLayout>new StackLayout();
                    stacktemp.orientation = "horizontal";
                    stacktemp.width = "100%";
                    var s = c + "." + Config.receipts[c]["PickUpTime"] + " to " + Config.receipts[c]["DropOffTime"];
                    // var s = Config.receipts[c]["DropOffTime"];
                    // console.log(s);
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.value = Config.receipts[c];
                    labeltemp.on(Button.tapEvent, (data: EventData) => {
                        // console.log("test");
                        Config.pReceipt = data.object.get("value");
                        // console.log("test");
                        this.router.navigate(["/viewreceipt"]);
                        // console.log("test");
                    });
                    stack.addChild(labeltemp);

                    // labeltemp = <Label>new Label();
                    // var cs = Config.receipts[c]["PickUpTime"];
                    // labeltemp.text = cs;
                    // labeltemp.width = "100%";
                    // stack.addChild(labeltemp);
                    stacktemp.addChild(stack);
                    parent.addChild(stacktemp);
                    c++;
                }
            }

        },
            () => alert("Unfortunately we were unable fetch all the terminals."));
    }
}