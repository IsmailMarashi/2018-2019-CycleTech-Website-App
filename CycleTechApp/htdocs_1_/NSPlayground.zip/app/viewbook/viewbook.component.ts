import { Component, OnInit } from "@angular/core";
import { User } from "../shared/user/user.model";
import { UserService } from "../shared/user/user.service";
import { Router } from "@angular/router";
import { Page } from "tns-core-modules/ui/page";
import { throwError } from 'rxjs';
import { AppModule } from '../app.module';
import { Config } from '../shared/config';
import { ViewChild } from "@angular/core";
import { EventData } from "tns-core-modules/data/observable";
import { getViewById } from "tns-core-modules/ui/core/view";
import { Label } from "tns-core-modules/ui/label";
import { StackLayout } from "tns-core-modules/ui/layouts/stack-layout";
import { Button } from "tns-core-modules/ui/button";
import { View } from "tns-core-modules/ui/core/view";
import { CartComponent } from "../shared/cartfunctions";
import { GridLayout } from "ui/layouts/grid-layout";

@Component({
    selector: "gr-viewbook",
    providers: [UserService, CartComponent],
    styleUrls: ["app.css"],
    templateUrl: "viewbook/viewbook.component.xml"
})

@Component({
    selector: "gr-app",
    template: "<page-router-outlet></page-router-outlet>"
})

export class ViewBookComponent implements OnInit {
    textFieldValue: string = "";
    receiptid: Number = -1;

    user: User;
    constructor(private router: Router, private userService: UserService, private page: Page, private cart: CartComponent) {
        this.user = new User();
    }
    back() {
        // alert();
        this.router.navigate(["/bookings"]);
    }
    cancel() {
        this.cart.cancelOrder(Config.pReceipt["receiptID"]).subscribe();
        this.router.navigate(["/bookings"]);
    }
    submit() {
        if (this.textFieldValue != "") {
            this.cart.submitComplaint(Config.pReceipt["receiptID"], "Admin: " + this.textFieldValue).subscribe();
            this.router.navigate(["/bookings"]);
        }
        else alert("Response field cannot be empty when submitting a response");
    }
    ngOnInit() {
        this.page.actionBarHidden = true;

        this.userService.getReceipts(Config.receipts).subscribe(() => {
            var c = 0;
            let stacktemp;
            let stack;
            let labeltemp;
            let parent = <StackLayout>getViewById(this.page, "stack");
            if (parent) {
                if (Config.pReceipt != null) {
                    var s;
                    s = "Customer ID:" + Config.pReceipt["MemberId"];
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    parent.addChild(labeltemp);
                    s = "Receipt ID:" + Config.pReceipt["receiptID"];
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    parent.addChild(labeltemp);
                    s = "bikeCount: " + Config.pReceipt["bikeCount"];
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    labeltemp.color = "green";
                    labeltemp.value = Config.pReceipt["receiptID"];
                    labeltemp.on(Button.tapEvent, (data: EventData) => {
                        // Config.receiptID = data.object.get("value");
                        // console.log(Config.receiptID);
                        alert("implement");
                        // this.router.navigate(["/viewreceipt"]);
                    });
                    parent.addChild(labeltemp);
                    s = "Time and Locations";
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    parent.addChild(labeltemp);
                    s = "Pickup Time and Location:";
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    parent.addChild(labeltemp);
                    s = "T:" + Config.pReceipt["PickUpTime"] + " | " + Config.pReceipt["pickUpTerminalName"];
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    parent.addChild(labeltemp);
                    s = "Drop Off Time and Location:";
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    parent.addChild(labeltemp);
                    s = "T:" + Config.pReceipt["dropOffTerminal"] + " | " + Config.pReceipt["dropOffTerminalName"];
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    parent.addChild(labeltemp);
                    s = "Rental Time(M): " + Config.pReceipt["RentalLength"];
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    parent.addChild(labeltemp);
                    s = "Fee: " + Config.pReceipt["AmountPaid"];
                    labeltemp = <Label>new Label();
                    labeltemp.text = s;
                    labeltemp.width = "100%";
                    labeltemp.row = c;
                    labeltemp.class = "h3 m-15";
                    parent.addChild(labeltemp);
                    c++;
                }

                var a = this.cart.complaints(Config.pReceipt["receiptID"]).subscribe(() => {
                    parent = <StackLayout>getViewById(this.page, "complaint");
                    c = 0;
                    while (Config.complaints[c] != null) {
                        s = (c + 1) + "." + Config.complaints[c]['CDate'];
                        labeltemp = <Label>new Label();
                        labeltemp.width = "100%";
                        labeltemp.row = c;
                        labeltemp.class = "h3 m-15";
                        labeltemp.value = Config.complaints[c]['Complaint'];
                        labeltemp.text = s;
                        labeltemp.on(Button.tapEvent, (data: EventData) => {
                            alert(data.object.get("value"));
                        });
                        parent.addChild(labeltemp);
                        Config.complaints;
                        c++
                    }
                });
                Config.complaints = new Array<JSON>();
            }

        },
            () => alert("Unfortunately we were unable fetch all the terminals."));
    }
}