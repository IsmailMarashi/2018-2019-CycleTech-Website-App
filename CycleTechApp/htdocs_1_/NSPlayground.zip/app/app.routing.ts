import { LoginComponent } from "./login/login.component";
import { HomeComponent } from "./home/home.component";
import { SignupComponent } from "./signup/signup.component";
import { UserinfoComponent } from "./userinfo/userinfo.component";
import { TerminalComponent } from "./terminal/terminal.component";
import { BookComponent } from "./book/book.component";
import { ViewCartComponent } from "./viewcart/viewcart.component";
import { FromComponent } from "./checkout/from/from.component";
import { ToComponent } from "./checkout/to/to.component";
import { SubmitOrderComponent } from "./submitorder/submitorder.component";
import { ReceiptsComponent } from "./receipts/receipts.component";
import { BikeEMUComponent } from "./bikeEMU/bikeEMU.component";
import { ViewReceiptComponent } from "./viewreceipt/viewreceipt.component";
import { AddBikeComponent } from "./addBike/addBike.component";
import { ViewBikeComponent } from "./viewbike/viewbike.component";
import { BookingsComponent } from "./bookings/bookings.component";
import { ViewBookComponent } from "./viewbook/viewbook.component";
import { TerminalBikesComponent } from "./terminalbikes/terminalbikes.component";
import { AdminComponent } from "./admin/admin.component";
import { BikeMapComponent } from "./bikemap/bikemap.component";



export const routes = [
    // { path: "", component: BikeMapComponent },
    // { path: "", component: AdminComponent },

    { path: "", component: LoginComponent },
    // { path: "", component: SignupComponent },
    // { path: "", component: DBComponent },
    // { path: "", component: TerminalComponent },
    // { path: "", component: ViewCartComponent },
    // { path: "", component: ToComponent },
    // { path: "", component: FromComponent },
    // { path: "", component: BikeEMUComponent },
    // { path: "", component: ReceiptsComponent },
    // { path: "", component: HomeComponent },
    // { path: "", component: BookComponent },
    // { path: "", component: BookingsComponent },
    // { path: "", component: ViewBikeComponent },
    // { path: "", component: TerminalBikesComponent },
    // { path: "", component: BookComponent },
    // { path: "", component: ViewReceiptComponent },
    { path: "terminalbikes", component: TerminalBikesComponent },
    // { path: "", component: BookingsComponent },
    { path: "bikemap", component: BikeMapComponent },
    { path: "admin", component: AdminComponent },
    { path: "viewbook", component: ViewBookComponent },
    { path: "bookings", component: BookingsComponent },
    { path: "viewbike", component: ViewBikeComponent },
    { path: "addbike", component: AddBikeComponent },
    { path: "viewreceipt", component: ViewReceiptComponent },
    { path: "home", component: HomeComponent },
    { path: "bikeEMU", component: BikeEMUComponent },
    { path: "receipts", component: ReceiptsComponent },
    { path: "submitorder", component: SubmitOrderComponent },
    { path: "viewcart", component: ViewCartComponent },
    { path: "terminal", component: TerminalComponent },
    { path: "book", component: BookComponent },
    { path: "signup", component: SignupComponent },
    { path: "userinfo", component: UserinfoComponent },
    { path: "from", component: FromComponent },
    { path: "to", component: ToComponent },

];

export const navigatableComponents = [
    TerminalBikesComponent,
    BikeMapComponent,
    LoginComponent,
    ViewBookComponent,
    AdminComponent,
    BookingsComponent,
    ViewBikeComponent,
    AddBikeComponent,
    ViewReceiptComponent,
    BikeEMUComponent,
    ReceiptsComponent,
    SubmitOrderComponent,
    ToComponent,
    FromComponent,
    ViewCartComponent,
    BookComponent,
    TerminalComponent,
    HomeComponent,
    UserinfoComponent,
    SignupComponent
];